/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bo.gob.asfi.uif.swi.model;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 *
 * @author John
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FieldSet extends org.heyma.core.extjs.components.FieldSet {
}
