/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bo.gob.asfi.uif.swi.model;

/**
 *
 * @author John
 */
public class HibernateConfig {
 
    
//    final Configuration configuration = new Configuration();
//    final Reflections reflections = new Reflections(Item.class.getPackage().getName());
//    final Set<Class<?>> classes = reflections.getTypesAnnotatedWith(Entity.class);
//    for (final Class<?> clazz : classes) {
//        configuration.addAnnotatedClass(clazz);
//    }
//            ServiceRegistry serviceRegistry=new ServiceRegistryBuilder().applySettings
//(configuration.getProperties()).buildServiceRegistry();        
//
//    return configuration.buildSessionFactory(serviceRegistry);
}
