/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bo.gob.asfi.uif.swi.services;

/**
 *
 * @author John
 */
public class Person {
    
}
