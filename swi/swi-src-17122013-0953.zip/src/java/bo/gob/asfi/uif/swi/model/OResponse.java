/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bo.gob.asfi.uif.swi.model;

import java.util.List;

/**
 *
 * @author John
 */
public class OResponse {

    private List<ElementParam> elements;

    public List<ElementParam> getElements() {
        return elements;
    }

    public void setElements(List<ElementParam> elements) {
        this.elements = elements;
    }
}
